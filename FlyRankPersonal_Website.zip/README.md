# Kruthika Goud — FlyRank Personal Website

Live URL: https://kruthika-protofolio.vercel.app/
GitHub: https://github.com/kruthikagoud20
LinkedIn: https://www.linkedin.com/in/kruthika-goud-9b5b8a2a2

## Files
- index.html — main one-page portfolio
- cv.html — CV page
- style.css — responsive styling
- DNS-Walkthrough.pdf — FlyRank DNS deliverable

The site uses plain HTML and CSS so every deployed file is understandable and maintainable.
